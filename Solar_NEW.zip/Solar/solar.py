# ============================================================
# PREDICTING SOLAR ENERGY POTENTIAL ACROSS SRI Lankan DISTRICTS
# SDG 7: Affordable and Clean Energy
# Course: LB 3124 - Data Visualisation and Storytelling
# ============================================================

# ── REQUIRED LIBRARIES ───────────────────────────────────────
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import warnings
warnings.filterwarnings('ignore')

# Styling
plt.rcParams['figure.dpi'] = 150
sns.set_style("whitegrid")

# ============================================================
# STEP 1: LOAD & INSPECT DATASET
# ============================================================
df = pd.read_csv('sri_lanka_solar_energy_dataset.csv')

print("=" * 60)
print("DATASET OVERVIEW")
print("=" * 60)
print(f"Shape         : {df.shape[0]} rows × {df.shape[1]} columns")
print(f"Districts     : {df['District'].nunique()}")
print(f"Provinces     : {df['Province'].nunique()}")
print(f"Climate Zones : {df['Climate_Zone'].nunique()}")
print("\nColumn Names:")
for col in df.columns:
    print(f"  - {col}")

print("\nData Types:\n", df.dtypes)
print("\nBasic Statistics:\n", df.describe())
print("\nMissing Values:\n", df.isnull().sum())

# ============================================================
# STEP 2: DATA CLEANING & PREPROCESSING
# ============================================================
print("\n" + "=" * 60)
print("DATA CLEANING & PREPROCESSING")
print("=" * 60)

# Fix mixed-type column
df['Renewable_Energy_Target_MW'] = pd.to_numeric(df['Renewable_Energy_Target_MW'], errors='coerce')

# Fill missing numeric values with median
num_cols = df.select_dtypes(include=np.number).columns
df[num_cols] = df[num_cols].fillna(df[num_cols].median())

print(f"Missing values after cleaning: {df.isnull().sum().sum()}")

# Label Encode categorical features
le = LabelEncoder()
df_ml = df.copy()
for col in ['Province', 'Climate_Zone', 'Solar_Irradiance_Category']:
    df_ml[col] = le.fit_transform(df_ml[col])
    print(f"Encoded: {col}")

# Features & Target
TARGET = 'PVOUT_kWh_kWp_year'
DROP_COLS = ['District', 'District_Code', TARGET]

X = df_ml.drop(columns=DROP_COLS)
X = X.select_dtypes(include=np.number)
y = df_ml[TARGET]

print(f"\nFeatures shape : {X.shape}")
print(f"Target         : {TARGET}")
print(f"Target range   : {y.min()} – {y.max()} kWh/kWp/year")

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-Test Split (80/20)
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)
print(f"\nTrain samples  : {X_train.shape[0]}")
print(f"Test samples   : {X_test.shape[0]}")

# ============================================================
# STEP 3: EXPLORATORY DATA ANALYSIS (EDA)
# ============================================================
print("\n" + "=" * 60)
print("EXPLORATORY DATA ANALYSIS")
print("=" * 60)

# ── FIGURE 1: PVOUT by District ──────────────────────────────
fig, ax = plt.subplots(figsize=(14, 8))
sorted_df = df.sort_values('PVOUT_kWh_kWp_year', ascending=True)
colors = [
    '#c0392b' if v >= 1800 else '#2980b9' if v >= 1600 else '#7f8c8d'
    for v in sorted_df['PVOUT_kWh_kWp_year']
]
bars = ax.barh(sorted_df['District'], sorted_df['PVOUT_kWh_kWp_year'],
               color=colors, edgecolor='white')
for bar, val in zip(bars, sorted_df['PVOUT_kWh_kWp_year']):
    ax.text(bar.get_width() + 8, bar.get_y() + bar.get_height() / 2,
            f'{val:,}', va='center', fontsize=8)
ax.set_xlabel('PVOUT (kWh/kWp/year)', fontsize=12)
ax.set_title('Solar PV Output Potential by District\n(Target Variable: PVOUT_kWh_kWp_year)',
             fontsize=14, fontweight='bold')
patches = [
    mpatches.Patch(color='#c0392b', label='Very High (≥1800)'),
    mpatches.Patch(color='#2980b9', label='High (1600–1799)'),
    mpatches.Patch(color='#7f8c8d', label='Medium (<1600)')
]
ax.legend(handles=patches, loc='lower right')
ax.set_xlim(0, 2200)
plt.tight_layout()
plt.savefig('fig1_pvout_by_district.png', bbox_inches='tight')
plt.show()

# ── FIGURE 2: PVOUT by Province & Climate Zone ───────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
province_order = df.groupby('Province')['PVOUT_kWh_kWp_year'].median()\
    .sort_values(ascending=False).index
sns.boxplot(data=df, x='Province', y='PVOUT_kWh_kWp_year',
            order=province_order, palette='Blues_r', ax=axes[0])
axes[0].set_xticklabels(axes[0].get_xticklabels(), rotation=35, ha='right', fontsize=9)
axes[0].set_title('PVOUT by Province', fontsize=12, fontweight='bold')
axes[0].set_xlabel('')

climate_order = df.groupby('Climate_Zone')['PVOUT_kWh_kWp_year'].median()\
    .sort_values(ascending=False).index
sns.boxplot(data=df, x='Climate_Zone', y='PVOUT_kWh_kWp_year',
            order=climate_order, palette='YlOrRd_r', ax=axes[1])
axes[1].set_xticklabels(axes[1].get_xticklabels(), rotation=25, ha='right', fontsize=9)
axes[1].set_title('PVOUT by Climate Zone', fontsize=12, fontweight='bold')
axes[1].set_xlabel('')
plt.suptitle('Solar Energy Potential by Geographic Categories',
             fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig('fig2_province_climate.png', bbox_inches='tight')
plt.show()

# ── FIGURE 3: Correlation Analysis ───────────────────────────
num_df = df.select_dtypes(include=np.number)
corr = num_df.corr()
pvout_corr = corr['PVOUT_kWh_kWp_year'].drop('PVOUT_kWh_kWp_year').sort_values()

fig, axes = plt.subplots(1, 2, figsize=(18, 8))
key_feats = ['PVOUT_kWh_kWp_year', 'GHI_kWh_m2_year', 'DNI_kWh_m2_year',
             'GTI_kWh_m2_year', 'Avg_Daily_Sunshine_hours', 'Cloud_Cover_percent',
             'Avg_Temp_Celsius', 'Avg_Humidity_percent', 'Annual_Rainfall_mm',
             'Elevation_m_avg', 'Latitude']
sns.heatmap(num_df[key_feats].corr(), annot=True, fmt='.2f', cmap='coolwarm',
            linewidths=0.5, ax=axes[0], annot_kws={'size': 8})
axes[0].set_title('Correlation Matrix (Key Features)', fontsize=12, fontweight='bold')
axes[0].tick_params(axis='x', rotation=45, labelsize=8)
axes[0].tick_params(axis='y', rotation=0, labelsize=8)

colors_corr = ['#e74c3c' if v > 0 else '#3498db' for v in pvout_corr]
axes[1].barh(pvout_corr.index, pvout_corr.values, color=colors_corr, edgecolor='white')
axes[1].axvline(0, color='black', linewidth=0.8)
axes[1].set_title('Feature Correlation with PVOUT', fontsize=12, fontweight='bold')
axes[1].set_xlabel('Pearson Correlation Coefficient')
axes[1].tick_params(labelsize=8)
patches2 = [
    mpatches.Patch(color='#e74c3c', label='Positive Correlation'),
    mpatches.Patch(color='#3498db', label='Negative Correlation')
]
axes[1].legend(handles=patches2)
plt.tight_layout()
plt.savefig('fig3_correlation.png', bbox_inches='tight')
plt.show()

# ── FIGURE 4: Feature Distributions ─────────────────────────
features_to_plot = ['GHI_kWh_m2_year', 'Avg_Daily_Sunshine_hours', 'Cloud_Cover_percent',
                    'Avg_Temp_Celsius', 'Annual_Rainfall_mm', 'Elevation_m_avg']
fig, axes = plt.subplots(2, 3, figsize=(15, 8))
axes = axes.flatten()
for i, feat in enumerate(features_to_plot):
    axes[i].hist(df[feat], bins=8, color='#2980b9', edgecolor='white', alpha=0.85)
    axes[i].axvline(df[feat].mean(), color='#e74c3c', linestyle='--', linewidth=1.5,
                    label=f'Mean: {df[feat].mean():.1f}')
    axes[i].set_title(feat.replace('_', ' '), fontsize=10, fontweight='bold')
    axes[i].legend(fontsize=8)
plt.suptitle('Distribution of Key Meteorological & Geographic Features',
             fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig('fig4_distributions.png', bbox_inches='tight')
plt.show()

# ── FIGURE 5: Scatter - GHI & Cloud Cover vs PVOUT ──────────
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
climate_colors = {
    'Tropical Dry': '#e74c3c',
    'Tropical Wet': '#3498db',
    'Tropical Highland': '#27ae60',
    'Tropical Intermediate': '#f39c12'
}
for climate, group in df.groupby('Climate_Zone'):
    c = climate_colors.get(climate, 'gray')
    axes[0].scatter(group['GHI_kWh_m2_year'], group['PVOUT_kWh_kWp_year'],
                    label=climate, color=c, s=100, edgecolors='white', linewidth=0.8)
    axes[1].scatter(group['Cloud_Cover_percent'], group['PVOUT_kWh_kWp_year'],
                    label=climate, color=c, s=100, edgecolors='white', linewidth=0.8)
for _, row in df.iterrows():
    axes[0].annotate(row['District'], (row['GHI_kWh_m2_year'], row['PVOUT_kWh_kWp_year']),
                     fontsize=5.5, ha='center', va='bottom')
    axes[1].annotate(row['District'], (row['Cloud_Cover_percent'], row['PVOUT_kWh_kWp_year']),
                     fontsize=5.5, ha='center', va='bottom')
axes[0].set_xlabel('GHI (kWh/m²/year)', fontsize=11)
axes[0].set_ylabel('PVOUT (kWh/kWp/year)', fontsize=11)
axes[0].set_title('GHI vs PVOUT by Climate Zone', fontsize=12, fontweight='bold')
axes[0].legend(fontsize=8)
axes[1].set_xlabel('Cloud Cover (%)', fontsize=11)
axes[1].set_ylabel('PVOUT (kWh/kWp/year)', fontsize=11)
axes[1].set_title('Cloud Cover vs PVOUT by Climate Zone', fontsize=12, fontweight='bold')
axes[1].legend(fontsize=8)
plt.tight_layout()
plt.savefig('fig5_scatter.png', bbox_inches='tight')
plt.show()

# ============================================================
# STEP 4: MODEL TRAINING & EVALUATION
# ============================================================
print("\n" + "=" * 60)
print("MODEL TRAINING & EVALUATION")
print("=" * 60)

models = {
    'Linear Regression':    LinearRegression(),
    'Random Forest':        RandomForestRegressor(n_estimators=200, random_state=42, max_depth=10),
    'Gradient Boosting':    GradientBoostingRegressor(n_estimators=200, learning_rate=0.05, random_state=42),
    'SVR':                  SVR(kernel='rbf', C=100, epsilon=0.1)
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred   = model.predict(X_test)
    cv_scores = cross_val_score(model, X_scaled, y, cv=5, scoring='r2')
    results[name] = {
        'R2':          r2_score(y_test, y_pred),
        'RMSE':        np.sqrt(mean_squared_error(y_test, y_pred)),
        'MAE':         mean_absolute_error(y_test, y_pred),
        'CV_R2_mean':  cv_scores.mean(),
        'CV_R2_std':   cv_scores.std(),
        'y_pred':      y_pred
    }
    print(f"  {name:25s} | R²={results[name]['R2']:.4f} | "
          f"RMSE={results[name]['RMSE']:.2f} | "
          f"MAE={results[name]['MAE']:.2f} | "
          f"CV_R²={cv_scores.mean():.4f}±{cv_scores.std():.4f}")

# ── FIGURE 6: Model Performance Comparison ───────────────────
names = list(results.keys())
r2s   = [results[n]['R2']   for n in names]
rmses = [results[n]['RMSE'] for n in names]
maes  = [results[n]['MAE']  for n in names]

fig, axes = plt.subplots(1, 3, figsize=(16, 6))

def bar_chart(ax, values, names, title, highlight='max'):
    best = max(values) if highlight == 'max' else min(values)
    colors = ['#e74c3c' if v == best else '#2980b9' for v in values]
    ax.bar(names, values, color=colors, edgecolor='white')
    ax.set_title(title, fontsize=11, fontweight='bold')
    ax.set_xticklabels(names, rotation=20, ha='right', fontsize=9)
    for i, v in enumerate(values):
        ax.text(i, v * 1.02, f'{v:.4f}' if v < 2 else f'{v:.1f}',
                ha='center', fontsize=9)

bar_chart(axes[0], r2s,   names, 'R² Score (Higher = Better)',  highlight='max')
axes[0].set_ylim(0, 1.15)
bar_chart(axes[1], rmses, names, 'RMSE (Lower = Better)',        highlight='min')
bar_chart(axes[2], maes,  names, 'MAE (Lower = Better)',         highlight='min')
plt.suptitle('Machine Learning Model Performance Comparison', fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig('fig6_model_comparison.png', bbox_inches='tight')
plt.show()

# ── FIGURE 7: Actual vs Predicted + Residuals ───────────────
best_model_name = max(results, key=lambda x: results[x]['R2'])
best_pred = results[best_model_name]['y_pred']

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
axes[0].scatter(y_test, best_pred, color='#2980b9', s=120, edgecolors='white')
mn, mx = min(min(y_test), min(best_pred)), max(max(y_test), max(best_pred))
axes[0].plot([mn, mx], [mn, mx], 'r--', linewidth=1.5, label='Perfect Prediction')
axes[0].set_xlabel('Actual PVOUT', fontsize=11)
axes[0].set_ylabel('Predicted PVOUT', fontsize=11)
axes[0].set_title(f'Actual vs Predicted — {best_model_name}', fontsize=12, fontweight='bold')
axes[0].legend()

residuals = np.array(best_pred) - np.array(y_test)
axes[1].bar(range(len(residuals)), residuals,
            color=['#e74c3c' if r > 0 else '#3498db' for r in residuals],
            edgecolor='white')
axes[1].axhline(0, color='black', linewidth=1)
axes[1].set_title('Residuals (Predicted − Actual)', fontsize=12, fontweight='bold')
axes[1].set_xlabel('Test Sample Index')
axes[1].set_ylabel('Residual')
plt.tight_layout()
plt.savefig('fig7_actual_vs_predicted.png', bbox_inches='tight')
plt.show()

# ── FIGURE 8: Feature Importance ─────────────────────────────
rf_model = models['Random Forest']
feat_importance = pd.Series(
    rf_model.feature_importances_, index=X.columns
).sort_values(ascending=True).tail(15)

fig, ax = plt.subplots(figsize=(12, 7))
max_fi = feat_importance.max()
colors_fi = [
    '#e74c3c' if v >= max_fi * 0.7 else '#2980b9' if v >= max_fi * 0.4 else '#7f8c8d'
    for v in feat_importance.values
]
ax.barh(feat_importance.index, feat_importance.values, color=colors_fi, edgecolor='white')
ax.set_title('Top 15 Feature Importances — Random Forest', fontsize=13, fontweight='bold')
ax.set_xlabel('Importance Score', fontsize=11)
for i, v in enumerate(feat_importance.values):
    ax.text(v + 0.002, i, f'{v:.4f}', va='center', fontsize=8)
plt.tight_layout()
plt.savefig('fig8_feature_importance.png', bbox_inches='tight')
plt.show()

# ── FIGURE 9: Cross-Validation ───────────────────────────────
cv_means = [results[n]['CV_R2_mean'] for n in names]
cv_stds  = [results[n]['CV_R2_std']  for n in names]

fig, ax = plt.subplots(figsize=(10, 6))
best_cv = max(cv_means)
bar_colors_cv = ['#e74c3c' if v == best_cv else '#2980b9' for v in cv_means]
ax.bar(names, cv_means, yerr=cv_stds, capsize=6, color=bar_colors_cv,
       edgecolor='white', error_kw={'linewidth': 2})
for i, (v, s) in enumerate(zip(cv_means, cv_stds)):
    ax.text(i, v + s + 0.02, f'{v:.4f}±{s:.4f}', ha='center', fontsize=9)
ax.set_ylim(0, 1.3)
ax.set_title('5-Fold Cross-Validation R² Score', fontsize=13, fontweight='bold')
ax.set_ylabel('Mean R² Score')
ax.set_xticklabels(names, rotation=20, ha='right')
plt.tight_layout()
plt.savefig('fig9_cross_validation.png', bbox_inches='tight')
plt.show()

# ============================================================
# STEP 5: FINAL RESULTS SUMMARY
# ============================================================
print("\n" + "=" * 60)
print("FINAL RESULTS SUMMARY")
print("=" * 60)
print(f"\n{'Model':<25} {'R²':>8} {'RMSE':>8} {'MAE':>8} {'CV R²':>12}")
print("-" * 65)
for name in names:
    r = results[name]
    print(f"{name:<25} {r['R2']:>8.4f} {r['RMSE']:>8.2f} {r['MAE']:>8.2f} {r['CV_R2_mean']:>8.4f}±{r['CV_R2_std']:.4f}")

best = max(results, key=lambda x: results[x]['R2'])
print(f"\n🏆 Best Model: {best}")
print(f"   R²   = {results[best]['R2']:.4f}")
print(f"   RMSE = {results[best]['RMSE']:.2f} kWh/kWp/year")
print(f"   MAE  = {results[best]['MAE']:.2f} kWh/kWp/year")

print("\n✅ Analysis complete! All 9 figures saved.")
print("   These figures can be used directly in your IEEE research paper.")